/* tslint:disable */
/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { GoogleGenAI } from '@google/genai';

// Fix: Define and use AIStudio interface for window.aistudio to resolve type conflict.
// Define the aistudio property on the window object for TypeScript
declare global {
  interface AIStudio {
    openSelectKey: () => Promise<void>;
  }
  interface Window {
    aistudio?: AIStudio;
  }
}

// --- Interfaces ---
interface VideoConfig {
  aspectRatio?: string;
  durationSeconds?: number;
  fps?: number;
  generateAudio?: boolean;
  resolution?: string;
}

async function openApiKeyDialog() {
  if (window.aistudio?.openSelectKey) {
    await window.aistudio.openSelectKey();
  } else {
    // This provides a fallback for environments where the dialog isn't available
    showStatusError(
      'API key selection is not available. Please configure the API_KEY environment variable.',
    );
  }
}

async function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function blobToBase64(blob: Blob) {
  return new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      const url = reader.result as string;
      // Return only the Base64 part of the data URL
      resolve(url.split(',')[1]);
    };
    reader.readAsDataURL(blob);
  });
}

function downloadFile(url, filename) {
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

// --- DOM Element Selection ---
const upload = document.querySelector('#file-input') as HTMLInputElement;
const promptEl = document.querySelector('#prompt-input') as HTMLTextAreaElement;
const generateButton = document.querySelector(
  '#generate-button',
) as HTMLButtonElement;
const apiKeyButton = document.querySelector(
  '#api-key-button',
) as HTMLButtonElement;
const videoContainer = document.querySelector(
  '#video-container',
) as HTMLDivElement;
const video = document.querySelector('#video') as HTMLVideoElement;
const downloadButton = document.querySelector(
  '#download-button',
) as HTMLButtonElement;
const fileNameEl = document.querySelector('#file-name') as HTMLSpanElement;
const imgPreview = document.querySelector('#img-preview') as HTMLImageElement;
const aspectRatioEl = document.querySelector(
  '#aspect-ratio-select',
) as HTMLSelectElement;
const resolutionEl = document.querySelector(
  '#resolution-select',
) as HTMLSelectElement;
const durationEl = document.querySelector(
  '#duration-input',
) as HTMLInputElement;
const fpsEl = document.querySelector('#fps-input') as HTMLInputElement;
const audioEl = document.querySelector('#audio-checkbox') as HTMLInputElement;
const spinnerEl = document.querySelector('#spinner') as HTMLDivElement;
const statusTextEl = document.querySelector(
  '#status-text',
) as HTMLParagraphElement;

async function generateContent(
  prompt: string,
  imageBytes: string,
  apiKey: string,
  config: VideoConfig = {},
): Promise<string> {
  const ai = new GoogleGenAI({ apiKey });

  // Dynamically build config object, only including properties that have values
  const videoConfig: { [key: string]: any } = {};
  if (config.aspectRatio) videoConfig.aspectRatio = config.aspectRatio;
  if (config.durationSeconds)
    videoConfig.durationSeconds = config.durationSeconds;
  if (config.fps) videoConfig.fps = config.fps;
  // Check for undefined because it could be `false` which is a valid value
  if (config.generateAudio !== undefined) {
    videoConfig.generateAudio = config.generateAudio;
  }
  if (config.resolution) videoConfig.resolution = config.resolution;

  const params: any = {
    model: 'veo-2.0-generate-001',
    prompt,
    config: {
      ...videoConfig,
      numberOfVideos: 1,
    },
  };

  if (imageBytes) {
    params.image = {
      imageBytes,
      mimeType: 'image/png', // Assuming PNG, adjust if supporting others
    };
  }

  let operation = await ai.models.generateVideos(params);

  statusTextEl.innerText = 'Generating...';

  let pollCount = 0;
  const maxPolls = 20;
  while (!operation.done && pollCount < maxPolls) {
    pollCount++;
    console.log('Waiting for completion');
    await delay(10000); // Poll every 10 seconds
    try {
      operation = await ai.operations.getVideosOperation({ operation });
    } catch (e) {
      console.error('Error polling for operation status:', e);
      throw new Error(
        'Failed to get video generation status. Please try again.',
      );
    }
  }

  if (!operation.done) {
    throw new Error(
      'Video generation timed out. Please try again with a simpler prompt.',
    );
  }

  const videos = operation.response?.generatedVideos;
  if (videos === undefined || videos.length === 0) {
    throw new Error(
      'No videos were generated. The prompt may have been blocked.',
    );
  }

  statusTextEl.innerText = 'Processing video...';

  const video = videos[0];
  const url = decodeURIComponent(video.video.uri);
  // Append API key for access
  const res = await fetch(`${url}&key=${apiKey}`);
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

// --- State Variables ---
let base64data = '';
let prompt = '';
let videoObjectURL = '';

// --- Event Listeners ---
upload.addEventListener('change', async (e) => {
  const file = (e.target as HTMLInputElement).files?.[0];
  if (file) {
    fileNameEl.textContent = file.name;
    base64data = await blobToBase64(file);
    imgPreview.src = `data:image/png;base64,${base64data}`;
    imgPreview.style.display = 'block';
  } else {
    fileNameEl.textContent = 'No file chosen';
    base64data = '';
    imgPreview.style.display = 'none';
  }
});

promptEl.addEventListener('input', () => {
  prompt = promptEl.value;
});

generateButton.addEventListener('click', () => {
  if (!prompt.trim()) {
    showStatusError('Please enter a prompt to generate a video.');
    return;
  }
  generate();
});

downloadButton.addEventListener('click', () => {
  if (videoObjectURL) {
    downloadFile(videoObjectURL, 'generated-video.mp4');
  }
});

apiKeyButton.addEventListener('click', async () => {
  await openApiKeyDialog();
});

// --- Functions ---
function showStatusError(message: string) {
  statusTextEl.innerHTML = `<span class="text-red-400">${message}</span>`;
}

function setControlsDisabled(disabled: boolean) {
  generateButton.disabled = disabled;
  upload.disabled = disabled;
  promptEl.disabled = disabled;
}

async function generate() {
  const apiKey = process.env.API_KEY;

  if (!apiKey) {
    showStatusError('API key is not configured. Please add your API key.');
    await openApiKeyDialog();
    return;
  }

  const videoConfig: VideoConfig = {
    aspectRatio: aspectRatioEl.value,
    resolution: resolutionEl.value,
    generateAudio: audioEl.checked,
  };

  const duration = parseInt(durationEl.value, 10);
  if (!isNaN(duration) && duration > 0) {
    videoConfig.durationSeconds = duration;
  }

  const fps = parseInt(fpsEl.value, 10);
  if (!isNaN(fps) && fps > 0) {
    videoConfig.fps = fps;
  }

  statusTextEl.innerText = 'Initializing...';
  spinnerEl.classList.remove('hidden');
  videoContainer.classList.add('hidden');
  downloadButton.classList.add('hidden');
  downloadButton.classList.remove('fade-in-up');
  video.src = '';
  if (videoObjectURL) {
    URL.revokeObjectURL(videoObjectURL);
    videoObjectURL = '';
  }
  setControlsDisabled(true);

  try {
    const objectURL = await generateContent(
      prompt,
      base64data,
      apiKey,
      videoConfig,
    );
    videoObjectURL = objectURL;
    video.src = videoObjectURL;
    videoContainer.classList.remove('hidden');
    statusTextEl.innerText = 'Video generated successfully.';

    // Make the download button appear with a slight delay and animation
    setTimeout(() => {
      downloadButton.classList.remove('hidden');
      downloadButton.classList.add('fade-in-up');
    }, 300);
  } catch (e) {
    console.error('Video generation failed:', e);
    const errorMessage =
      e instanceof Error ? e.message : 'An unknown error occurred.';

    let userFriendlyMessage = `Error: ${errorMessage}`;
    let shouldOpenDialog = false;

    if (typeof errorMessage === 'string') {
      if (errorMessage.includes('Requested entity was not found.')) {
        userFriendlyMessage =
          'Model not found. This can be caused by an invalid API key or permission issues. Please check your API key.';
        shouldOpenDialog = true;
      } else if (
        errorMessage.includes('API_KEY_INVALID') ||
        errorMessage.includes('API key not valid') ||
        errorMessage.toLowerCase().includes('permission denied')
      ) {
        userFriendlyMessage =
          'Your API key is invalid. Please add a valid API key.';
        shouldOpenDialog = true;
      }
    }

    showStatusError(userFriendlyMessage);

    if (shouldOpenDialog) {
      await openApiKeyDialog();
    }
  } finally {
    spinnerEl.classList.add('hidden');
    setControlsDisabled(false);
  }
}